<?php

include('connect.php');

$first_name = $_POST['firstname'];
$password=$_POST['password'];

$sql="select * from users where firstname='$first_name' and password='$password'";
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
if($count == 1)
{
    echo "login sucrssfull";
}
else{
    echo"login error";
}


