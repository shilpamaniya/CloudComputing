<?php

$servername="localhost";
$username="root";
$password="shilpa1612";
$dbname="phpexam";

$conn=mysqli_connect($servername,$username,$password,$dbname);

if($conn)
{
    echo "data base connected";
}
else{
    die("connection failed".mysqli_connect_errno());
}