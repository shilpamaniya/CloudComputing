
/**
 * Restful services here
 */
package ictmsa.msaclient.service;