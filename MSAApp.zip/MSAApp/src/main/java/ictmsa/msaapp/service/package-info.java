
/**
 * Restful services here
 */
package ictmsa.msaapp.service;